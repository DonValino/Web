(function(){
Template.body.addContent((function() {
  var view = this;
  return [ HTML.Raw("<div ng-include=\"'index.ng.html'\"></div>\n  "), HTML.SCRIPT({
    src: "https://ajax.googleapis.com/ajax/libs/angularjs/1.4.7/angular.min.js"
  }) ];
}));
Meteor.startup(Template.body.renderToDocument);

Meteor.startup(function() {
  document.body.setAttribute('ng-app', 'products');
  document.body.setAttribute('ng-strict-di', '');
});

}).call(this);
