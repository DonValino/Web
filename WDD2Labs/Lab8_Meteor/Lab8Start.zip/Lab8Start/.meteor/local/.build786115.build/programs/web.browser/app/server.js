(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Server side code not available on client                            //
Products = new Mongo.Collection("productCollection");                  // 2
                                                                       //
if (Meteor.isServer) {                                                 // 4
                                                                       //
    // Initialise the DB with sample data (if necessary)               //
    // Note the object syntax has changed from previous labs - number values are not quoted
    Meteor.startup(function () {                                       // 8
        if (Products.find().count() === 0) {                           // 9
            var sampleProducts = [{                                    // 10
                'id': 1,                                               // 12
                'name': 'Kettle',                                      // 13
                'description': 'Steel Electric Kettle',                // 14
                'category': 'Kitchen',                                 // 15
                'stock': 100,                                          // 16
                'price': 55.00 }, {                                    // 17
                'id': 2,                                               // 19
                'name': 'Fridge freezer',                              // 20
                'description': 'Fridge + freezer large',               // 21
                'category': 'kitchen',                                 // 22
                'stock': 45,                                           // 23
                'price': 799.00 }, {                                   // 24
                'id': 3,                                               // 26
                'name': 'Portable Music Player',                       // 27
                'description': '250GB music player (MP3, MP4, WMA, WAV)',
                'category': 'Audio',                                   // 29
                'stock': 5,                                            // 30
                'price': 99.00 }, {                                    // 31
                'id': 4,                                               // 33
                'name': '13inch Laptop',                               // 34
                'description': 'HP laptop, 8GB RAM, 250GB SSD',        // 35
                'category': 'Computer',                                // 36
                'stock': 45,                                           // 37
                'price': 799.00 }, {                                   // 38
                'id': 5,                                               // 40
                'name': '8inch Tablet',                                // 41
                'description': 'Android 5.1 Tablet, 32GB storage, 8inch screen',
                'category': 'Computer',                                // 43
                'stock': 5,                                            // 44
                'price': 99.00 }, {                                    // 45
                'id': 6,                                               // 47
                'name': '46inch TV',                                   // 48
                'description': 'Sony 4K, OLED, Smart TV',              // 49
                'category': 'Television',                              // 50
                'stock': 12,                                           // 51
                'price': 2799.00 }, {                                  // 52
                'id': 7,                                               // 54
                'name': 'Washing Machine',                             // 55
                'description': '1600rpm spin, A+++ rated, 10KG',       // 56
                'category': 'Laundry',                                 // 57
                'stock': 50,                                           // 58
                'price': 699.00 }, {                                   // 59
                'id': 8,                                               // 61
                'name': 'Phone',                                       // 62
                'description': 'Windows 10, 5.2inch OLED, 3GB RAM, 64GB Storage',
                'category': 'Mobile Phone',                            // 64
                'stock': 45,                                           // 65
                'price': 799.00 }, {                                   // 66
                'id': 9,                                               // 68
                'name': '10inch Tablet',                               // 69
                'description': 'Windows 10, 128GB storage, 8inch screen',
                'category': 'Computer',                                // 71
                'stock': 5,                                            // 72
                'price': 299.00 }, {                                   // 73
                'id': 10,                                              // 75
                'name': 'Oven',                                        // 76
                'description': 'Oven + Grill, Stainless Steel',        // 77
                'category': 'Kitchen',                                 // 78
                'stock': 10,                                           // 79
                'price': 399.00 }, {                                   // 80
                'id': 11,                                              // 82
                'name': 'Bed',                                         // 83
                'description': 'Super King size, super comfort mattress',
                'category': 'Furniture',                               // 85
                'stock': 5,                                            // 86
                'price': 899.00 }, {                                   // 87
                'id': 12,                                              // 89
                'name': 'Learning JavaScript',                         // 90
                'description': 'Become a JavaScript expert in 2 hours!',
                'category': 'Book',                                    // 92
                'stock': 50,                                           // 93
                'price': 29.00 }];                                     // 94
                                                                       //
            // Insert JS objects into collection                       //
            for (var i = 0; i < sampleProducts.length; i++) Products.insert(sampleProducts[i]);
        }                                                              //
    });                                                                //
    //Meteor Methods                                                   //
    Meteor.methods({                                                   // 103
                                                                       //
        //Add new product to the collection                            //
        addProduct: function (product) {                               // 106
            Products.insert(product);                                  // 107
        },                                                             //
                                                                       //
        //Update an existing product                                   //
        updateProduct: function (product) {                            // 111
            Products.update(product._id, product);                     // 112
        },                                                             //
                                                                       //
        //Delete a product by its collection id                        //
        deleteProduct: function (id) {                                 // 116
            Products.remove(id);                                       // 117
        }                                                              //
    });                                                                //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);
